
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { CheckCircle, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

const OrderConfirmationPage = () => {
  const orderNumber = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container-custom max-w-xl text-center py-12">
          <div className="flex justify-center">
            <div className="rounded-full bg-primary/10 p-3">
              <CheckCircle size={48} className="text-primary" />
            </div>
          </div>
          
          <h1 className="text-3xl font-medium mt-6">Order Confirmed!</h1>
          
          <p className="text-muted-foreground mt-4">
            Thank you for your purchase. Your order has been confirmed and will be shipped soon.
          </p>
          
          <div className="mt-8 p-6 border border-border rounded-lg">
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Package size={16} />
              <span>Order Number:</span>
              <span className="font-medium text-foreground">{orderNumber}</span>
            </div>
            
            <div className="mt-6 space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Order Date:</span>
                <span>{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Estimated Delivery:</span>
                <span>Within 3-5 business days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping Method:</span>
                <span>Standard Shipping</span>
              </div>
            </div>
          </div>
          
          <p className="mt-8 text-sm text-muted-foreground">
            A confirmation email has been sent to your email address with all the details of your order.
          </p>
          
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/account/orders">
              <Button variant="outline">View Order Status</Button>
            </Link>
            <Link to="/products">
              <Button>Continue Shopping</Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default OrderConfirmationPage;
