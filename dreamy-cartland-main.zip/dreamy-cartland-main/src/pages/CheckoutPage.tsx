
import { useState, FormEvent, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ChevronRight, CreditCard, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import { Address } from "@/types";

const CheckoutPage = () => {
  const { cart, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("credit-card");
  const [shippingAddress, setShippingAddress] = useState<Address>({
    fullName: "",
    street: "",
    city: "",
    state: "",
    zipCode: "",
    country: "United States"
  });
  
  const [cardDetails, setCardDetails] = useState({
    number: "",
    name: "",
    expiry: "",
    cvc: ""
  });
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    if (cart.items.length === 0) {
      navigate("/cart");
    }
    
    if (!user) {
      navigate("/login", { state: { from: { pathname: "/checkout" } } });
    }
  }, [cart.items.length, navigate, user]);
  
  const handleShippingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setShippingAddress(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCardDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (cart.items.length === 0) {
      navigate("/cart");
      return;
    }
    
    // Basic validation
    const { fullName, street, city, state, zipCode } = shippingAddress;
    if (!fullName || !street || !city || !state || !zipCode) {
      toast.error("Please complete all shipping information");
      return;
    }
    
    if (paymentMethod === "credit-card") {
      const { number, name, expiry, cvc } = cardDetails;
      if (!number || !name || !expiry || !cvc) {
        toast.error("Please complete all payment information");
        return;
      }
    }
    
    setIsLoading(true);
    
    // Simulate API call for order processing
    setTimeout(() => {
      clearCart();
      setIsLoading(false);
      navigate("/order-confirmation");
      
      toast.success("Your order has been placed successfully!");
    }, 1500);
  };
  
  const shipping = cart.subtotal > 50 ? 0 : 4.99;
  const tax = cart.subtotal * 0.07; // Assuming 7% tax rate
  const total = cart.subtotal + shipping + tax;
  
  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container-custom">
          <div className="mb-6">
            <h1 className="text-3xl font-medium">Checkout</h1>
            <div className="flex items-center text-sm mt-2">
              <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Home
              </Link>
              <ChevronRight size={14} className="mx-1 text-muted-foreground" />
              <Link to="/cart" className="text-muted-foreground hover:text-foreground transition-colors">
                Cart
              </Link>
              <ChevronRight size={14} className="mx-1 text-muted-foreground" />
              <span>Checkout</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit}>
                {/* Shipping Information */}
                <div className="border border-border rounded-lg p-6 mb-8">
                  <h2 className="text-xl font-medium mb-4">Shipping Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        value={shippingAddress.fullName}
                        onChange={handleShippingChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="street">Street Address</Label>
                      <Input
                        id="street"
                        name="street"
                        value={shippingAddress.street}
                        onChange={handleShippingChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        name="city"
                        value={shippingAddress.city}
                        onChange={handleShippingChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="state">State / Province</Label>
                      <Input
                        id="state"
                        name="state"
                        value={shippingAddress.state}
                        onChange={handleShippingChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="zipCode">ZIP / Postal Code</Label>
                      <Input
                        id="zipCode"
                        name="zipCode"
                        value={shippingAddress.zipCode}
                        onChange={handleShippingChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="country">Country</Label>
                      <Input
                        id="country"
                        name="country"
                        value={shippingAddress.country}
                        onChange={handleShippingChange}
                        required
                      />
                    </div>
                  </div>
                </div>
                
                {/* Payment Method */}
                <div className="border border-border rounded-lg p-6 mb-8">
                  <h2 className="text-xl font-medium mb-4">Payment Method</h2>
                  
                  <RadioGroup 
                    value={paymentMethod} 
                    onValueChange={setPaymentMethod}
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="credit-card" id="credit-card" />
                      <Label htmlFor="credit-card" className="flex items-center cursor-pointer">
                        <CreditCard size={18} className="mr-2" />
                        Credit / Debit Card
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="paypal" id="paypal" />
                      <Label htmlFor="paypal" className="cursor-pointer">
                        PayPal
                      </Label>
                    </div>
                  </RadioGroup>
                  
                  {paymentMethod === "credit-card" && (
                    <div className="mt-4 space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input
                          id="cardNumber"
                          name="number"
                          placeholder="0000 0000 0000 0000"
                          value={cardDetails.number}
                          onChange={handleCardChange}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="cardName">Name on Card</Label>
                        <Input
                          id="cardName"
                          name="name"
                          placeholder="John Doe"
                          value={cardDetails.name}
                          onChange={handleCardChange}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiry">Expiry Date</Label>
                          <Input
                            id="expiry"
                            name="expiry"
                            placeholder="MM/YY"
                            value={cardDetails.expiry}
                            onChange={handleCardChange}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="cvc">CVC</Label>
                          <Input
                            id="cvc"
                            name="cvc"
                            placeholder="123"
                            value={cardDetails.cvc}
                            onChange={handleCardChange}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="lg:hidden">
                  <OrderSummary 
                    cart={cart} 
                    shipping={shipping} 
                    tax={tax} 
                    total={total} 
                    isLoading={isLoading}
                  />
                </div>
                
                <div className="flex justify-between items-center mt-8">
                  <Link to="/cart" className="text-sm flex items-center hover:underline">
                    <ChevronRight size={14} className="mr-1 rotate-180" />
                    Return to Cart
                  </Link>
                  
                  <Button type="submit" size="lg" disabled={isLoading}>
                    {isLoading ? "Processing..." : "Place Order"}
                  </Button>
                </div>
              </form>
            </div>
            
            <div className="hidden lg:block">
              <OrderSummary 
                cart={cart} 
                shipping={shipping} 
                tax={tax} 
                total={total} 
                isLoading={isLoading}
              />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

const OrderSummary = ({ 
  cart, 
  shipping, 
  tax, 
  total,
  isLoading
}: { 
  cart: { items: { product: { id: string; name: string; price: number; image: string }; quantity: number }[]; subtotal: number }; 
  shipping: number; 
  tax: number; 
  total: number;
  isLoading: boolean;
}) => {
  return (
    <div className="border border-border rounded-lg p-6 sticky top-24">
      <h2 className="text-xl font-medium mb-4">Order Summary</h2>
      
      <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
        {cart.items.map((item) => (
          <div key={item.product.id} className="flex gap-3">
            <div className="w-16 h-16 rounded-md overflow-hidden bg-muted/30 flex-shrink-0">
              <img
                src={item.product.image}
                alt={item.product.name}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="flex justify-between">
                <p className="text-sm font-medium truncate max-w-[160px]">
                  {item.product.name}
                </p>
                <p className="text-sm font-medium">
                  ${item.product.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
              <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
            </div>
          </div>
        ))}
      </div>
      
      <Separator className="my-4" />
      
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Subtotal</span>
          <span>
            ${cart.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Shipping</span>
          <span>
            {shipping === 0 
              ? "Free" 
              : `$${shipping.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
            }
          </span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Tax (7%)</span>
          <span>
            ${tax.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
      </div>
      
      <Separator className="my-4" />
      
      <div className="flex justify-between font-medium text-lg mb-6">
        <span>Total</span>
        <span>
          ${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
      </div>
      
      <Button className="w-full" size="lg" form="checkout-form" disabled={isLoading}>
        {isLoading ? "Processing..." : "Place Order"}
      </Button>
      
      <div className="mt-4 flex items-center justify-center text-xs text-muted-foreground">
        <ShoppingBag size={14} className="mr-1" />
        <span>{cart.items.reduce((acc, item) => acc + item.quantity, 0)} items</span>
      </div>
    </div>
  );
};

export default CheckoutPage;
