
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

const NotFound = () => {
  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container-custom max-w-md text-center py-16">
          <h1 className="text-7xl font-medium">404</h1>
          <h2 className="text-2xl font-medium mt-4">Page Not Found</h2>
          <p className="mt-4 text-muted-foreground">
            The page you are looking for does not exist or has been moved.
          </p>
          <Link to="/">
            <Button className="mt-8">
              Return to Home
            </Button>
          </Link>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default NotFound;
