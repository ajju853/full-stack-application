
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ui/product-card";
import { CategoryCard } from "@/components/ui/category-card";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { categories } from "@/data/categories";
import { getFeaturedProducts, getBestSellerProducts } from "@/data/products";

const Index = () => {
  const featuredProducts = getFeaturedProducts();
  const bestSellerProducts = getBestSellerProducts();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1920&auto=format&fit=crop"
              alt="Hero background"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
          </div>
          
          <div className="container-custom relative z-10 mt-20 text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-medium leading-tight max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: "0.2s" }}>
              Elevate Your Everyday with Thoughtful Design
            </h1>
            <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: "0.4s" }}>
              Discover curated products that blend form and function for a more intentional lifestyle.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: "0.6s" }}>
              <Link to="/products">
                <Button size="lg" className="px-8">
                  Shop Now
                </Button>
              </Link>
              <Link to="/new-arrivals">
                <Button variant="outline" size="lg" className="px-8">
                  Explore New Arrivals
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-fade-in" style={{ animationDelay: "0.8s" }}>
            <div className="animate-bounce">
              <ArrowRight size={24} className="rotate-90" />
            </div>
          </div>
        </section>
        
        {/* Categories Section */}
        <section className="py-16 md:py-24 bg-muted/50">
          <div className="container-custom">
            <div className="flex flex-col md:flex-row justify-between items-baseline mb-10">
              <div>
                <h2 className="text-3xl font-medium">Shop by Category</h2>
                <p className="mt-2 text-muted-foreground">Explore our carefully curated collections</p>
              </div>
              <Link to="/products" className="mt-4 md:mt-0 group flex items-center text-sm font-medium">
                View All Categories
                <ArrowRight size={14} className="ml-1 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {categories.map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Featured Products Section */}
        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="flex flex-col md:flex-row justify-between items-baseline mb-10">
              <div>
                <h2 className="text-3xl font-medium">Featured Products</h2>
                <p className="mt-2 text-muted-foreground">Handpicked selections from our latest collections</p>
              </div>
              <Link to="/products" className="mt-4 md:mt-0 group flex items-center text-sm font-medium">
                View All Products
                <ArrowRight size={14} className="ml-1 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Content Section */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container-custom">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <img
                  src="https://images.unsplash.com/photo-1567016526105-22da7c13161a?q=80&w=800&auto=format&fit=crop"
                  alt="Minimalist product showcase"
                  className="rounded-lg shadow-subtle"
                />
              </div>
              <div>
                <h2 className="text-3xl font-medium">Crafted with Purpose</h2>
                <p className="mt-4 text-muted-foreground">
                  At Luminous, we believe that everyday objects should be thoughtfully designed, responsibly made, and built to last. Each product in our collection is selected for its exceptional quality, timeless design, and ability to enhance your daily experience.
                </p>
                <p className="mt-4 text-muted-foreground">
                  We partner with brands and artisans who share our commitment to ethical production and sustainable practices, ensuring that your purchase makes a positive impact.
                </p>
                <Link to="/about" className="mt-6 inline-block">
                  <Button variant="outline">Learn More About Us</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        {/* Best Sellers Section */}
        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="flex flex-col md:flex-row justify-between items-baseline mb-10">
              <div>
                <h2 className="text-3xl font-medium">Best Sellers</h2>
                <p className="mt-2 text-muted-foreground">Our most popular products that customers love</p>
              </div>
              <Link to="/products" className="mt-4 md:mt-0 group flex items-center text-sm font-medium">
                View All Products
                <ArrowRight size={14} className="ml-1 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {bestSellerProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Newsletter Section */}
        <section className="py-16 md:py-24 bg-primary text-primary-foreground">
          <div className="container-custom">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-medium">Stay in Touch</h2>
              <p className="mt-4">
                Subscribe to our newsletter to receive updates on new products, special offers, and curated content.
              </p>
              
              <form className="mt-8 flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 rounded-md border border-primary-foreground/20 bg-transparent px-4 py-2 text-primary-foreground placeholder:text-primary-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary-foreground/30"
                  required
                />
                <Button variant="secondary" type="submit">
                  Subscribe
                </Button>
              </form>
              
              <p className="mt-4 text-sm text-primary-foreground/70">
                By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Index;
