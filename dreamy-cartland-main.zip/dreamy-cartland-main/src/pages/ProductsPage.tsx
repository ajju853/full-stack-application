
import { useState, useEffect } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { Filter, SlidersHorizontal } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ui/product-card";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { products, getProductsByCategory } from "@/data/products";
import { getCategoryById } from "@/data/categories";
import { Product } from "@/types";

const sortOptions = [
  { value: "latest", label: "Newest First" },
  { value: "price-low", label: "Price: Low to High" },
  { value: "price-high", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
];

const priceRanges = [
  { value: "all", label: "All Prices" },
  { value: "0-50", label: "Under $50" },
  { value: "50-100", label: "From $50 to $100" },
  { value: "100-200", label: "From $100 to $200" },
  { value: "200+", label: "Over $200" },
];

const ProductsPage = () => {
  const { categoryId } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [sortBy, setSortBy] = useState(searchParams.get("sort") || "latest");
  const [priceRange, setPriceRange] = useState(searchParams.get("price") || "all");
  const [minRating, setMinRating] = useState(parseInt(searchParams.get("rating") || "0"));
  
  const category = categoryId ? getCategoryById(categoryId) : null;
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    let filtered = categoryId 
      ? getProductsByCategory(categoryId) 
      : [...products];
    
    // Apply price filter
    if (priceRange !== "all") {
      const [min, max] = priceRange.split("-").map(Number);
      if (max) {
        filtered = filtered.filter(product => product.price >= min && product.price <= max);
      } else {
        filtered = filtered.filter(product => product.price >= min);
      }
    }
    
    // Apply rating filter
    if (minRating > 0) {
      filtered = filtered.filter(product => product.rating >= minRating);
    }
    
    // Apply sorting
    if (sortBy === "price-low") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-high") {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortBy === "rating") {
      filtered.sort((a, b) => b.rating - a.rating);
    } else {
      // Default to latest (assuming id is sequential)
      filtered.sort((a, b) => parseInt(b.id) - parseInt(a.id));
    }
    
    setFilteredProducts(filtered);
    
    // Update URL search params
    const params: Record<string, string> = {};
    if (sortBy !== "latest") params.sort = sortBy;
    if (priceRange !== "all") params.price = priceRange;
    if (minRating > 0) params.rating = minRating.toString();
    
    setSearchParams(params, { replace: true });
  }, [categoryId, sortBy, priceRange, minRating, setSearchParams]);
  
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
  };
  
  const handlePriceChange = (value: string) => {
    setPriceRange(value);
  };
  
  const handleRatingChange = (rating: number) => {
    setMinRating(rating === minRating ? 0 : rating);
  };
  
  const clearFilters = () => {
    setPriceRange("all");
    setMinRating(0);
    setSortBy("latest");
  };
  
  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container-custom">
          {/* Page Title and Description */}
          <div className="mb-8">
            <h1 className="text-3xl font-medium">
              {category ? category.name : "All Products"}
            </h1>
            <p className="mt-2 text-muted-foreground">
              {category
                ? category.description
                : "Browse our full collection of carefully curated products"}
            </p>
          </div>
          
          {/* Filters and Sorting */}
          <div className="flex flex-col sm:flex-row justify-between gap-4 mb-8">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="sm:hidden flex items-center gap-2">
                  <Filter size={16} />
                  Filters
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <div className="space-y-6 py-4">
                  <div>
                    <h3 className="text-lg font-medium">Price Range</h3>
                    <div className="mt-3 space-y-2">
                      {priceRanges.map((range) => (
                        <div key={range.value} className="flex items-center">
                          <input
                            type="radio"
                            id={`mobile-price-${range.value}`}
                            name="mobile-price"
                            className="mr-2 h-4 w-4"
                            checked={priceRange === range.value}
                            onChange={() => handlePriceChange(range.value)}
                          />
                          <label htmlFor={`mobile-price-${range.value}`}>{range.label}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Minimum Rating</h3>
                    <div className="mt-3 flex gap-2">
                      {[4, 3, 2].map((rating) => (
                        <Button
                          key={rating}
                          variant={minRating === rating ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleRatingChange(rating)}
                        >
                          {rating}+ ★
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button variant="ghost" size="sm" onClick={clearFilters}>
                      Clear All
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            
            <div className="hidden sm:flex items-center gap-4">
              <Filter size={20} className="text-muted-foreground" />
              
              <div className="space-x-2">
                <span className="text-sm font-medium">Price:</span>
                {priceRanges.map((range) => (
                  <Button
                    key={range.value}
                    variant={priceRange === range.value ? "default" : "outline"}
                    size="sm"
                    onClick={() => handlePriceChange(range.value)}
                  >
                    {range.label}
                  </Button>
                ))}
              </div>
              
              <div className="space-x-2">
                <span className="text-sm font-medium">Rating:</span>
                {[4, 3, 2].map((rating) => (
                  <Button
                    key={rating}
                    variant={minRating === rating ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleRatingChange(rating)}
                  >
                    {rating}+ ★
                  </Button>
                ))}
              </div>
              
              {(priceRange !== "all" || minRating > 0) && (
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  Clear
                </Button>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <SlidersHorizontal size={16} className="text-muted-foreground" />
              <select
                className="bg-transparent text-sm focus:outline-none cursor-pointer"
                value={sortBy}
                onChange={handleSortChange}
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          {/* Product Grid */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="py-16 text-center">
              <h3 className="text-xl font-medium">No products found</h3>
              <p className="mt-2 text-muted-foreground">
                Try adjusting your filters to find what you're looking for.
              </p>
              <Button className="mt-4" onClick={clearFilters}>
                Clear All Filters
              </Button>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
};

export default ProductsPage;
