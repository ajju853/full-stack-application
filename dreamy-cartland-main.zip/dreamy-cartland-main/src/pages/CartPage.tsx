
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronRight, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { useCart } from "@/hooks/use-cart";

const CartPage = () => {
  const { cart, updateItemQuantity, removeItem } = useCart();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  const incrementQuantity = (productId: string, currentQuantity: number) => {
    updateItemQuantity(productId, currentQuantity + 1);
  };
  
  const decrementQuantity = (productId: string, currentQuantity: number) => {
    if (currentQuantity > 1) {
      updateItemQuantity(productId, currentQuantity - 1);
    }
  };
  
  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container-custom">
          <div className="mb-6">
            <h1 className="text-3xl font-medium">Shopping Cart</h1>
            <div className="flex items-center text-sm mt-2">
              <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Home
              </Link>
              <ChevronRight size={14} className="mx-1 text-muted-foreground" />
              <span>Cart</span>
            </div>
          </div>
          
          {cart.items.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="space-y-6">
                  {cart.items.map((item) => (
                    <div key={item.product.id} className="flex flex-col sm:flex-row gap-4 border border-border rounded-lg p-4">
                      <div className="sm:w-24 sm:h-24 aspect-square rounded-md overflow-hidden bg-muted/30 flex-shrink-0">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      
                      <div className="flex-1 flex flex-col">
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
                          <div>
                            <Link
                              to={`/product/${item.product.id}`}
                              className="font-medium hover:underline"
                            >
                              {item.product.name}
                            </Link>
                            <p className="text-sm text-muted-foreground mt-1">
                              {item.product.brand}
                            </p>
                          </div>
                          
                          <div className="text-right">
                            <p className="font-medium">
                              ${(item.product.price * item.quantity).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                            <p className="text-sm text-muted-foreground mt-1">
                              ${item.product.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} each
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between mt-auto pt-4">
                          <div className="flex items-center">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => decrementQuantity(item.product.id, item.quantity)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus size={12} />
                              <span className="sr-only">Decrease quantity</span>
                            </Button>
                            <span className="w-8 text-center text-sm">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => incrementQuantity(item.product.id, item.quantity)}
                            >
                              <Plus size={12} />
                              <span className="sr-only">Increase quantity</span>
                            </Button>
                          </div>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-muted-foreground hover:text-destructive"
                            onClick={() => removeItem(item.product.id)}
                          >
                            <Trash2 size={14} className="mr-1" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="flex items-center justify-between mt-6">
                  <Link to="/products">
                    <Button variant="outline" className="text-sm">
                      <ChevronRight size={14} className="mr-1 rotate-180" />
                      Continue Shopping
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div>
                <div className="border border-border rounded-lg p-6 bg-muted/30 sticky top-24">
                  <h2 className="text-xl font-medium mb-4">Order Summary</h2>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>
                        ${cart.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>Calculated at checkout</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Tax</span>
                      <span>Calculated at checkout</span>
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="flex justify-between font-medium mb-6">
                    <span>Total</span>
                    <span>
                      ${cart.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  
                  <Link to="/checkout">
                    <Button className="w-full">
                      Proceed to Checkout
                    </Button>
                  </Link>
                  
                  <div className="mt-4 text-xs text-muted-foreground text-center">
                    <p>
                      Free shipping on orders over $50. Easy returns.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-16 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-muted/50 rounded-full mb-6">
                <ShoppingBag size={32} className="text-muted-foreground" />
              </div>
              <h2 className="text-2xl font-medium">Your cart is empty</h2>
              <p className="mt-2 text-muted-foreground max-w-md mx-auto">
                Looks like you haven't added any products to your cart yet.
                Browse our collection to find something you'll love.
              </p>
              <Link to="/products">
                <Button className="mt-6">
                  Browse Products
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
};

export default CartPage;
