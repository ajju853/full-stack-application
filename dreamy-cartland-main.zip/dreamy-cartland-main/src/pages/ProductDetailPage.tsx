
import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { 
  ChevronRight, 
  Minus, 
  Plus, 
  ShoppingBag, 
  Star, 
  Truck,
  RefreshCw,
  Shield,
  Heart
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ProductCard } from "@/components/ui/product-card";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { getProductById, getRelatedProducts } from "@/data/products";
import { getReviewsByProductId } from "@/data/reviews";
import { useCart } from "@/hooks/use-cart";
import { Product } from "@/types";

const ProductDetailPage = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const { addItem } = useCart();
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    if (!productId) {
      navigate("/products");
      return;
    }
    
    const fetchedProduct = getProductById(productId);
    if (fetchedProduct) {
      setProduct(fetchedProduct);
      setRelatedProducts(getRelatedProducts(productId));
    } else {
      navigate("/products");
    }
    
    setLoading(false);
  }, [productId, navigate]);
  
  const reviews = product ? getReviewsByProductId(product.id) : [];
  
  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };
  
  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  const handleAddToCart = () => {
    if (product) {
      addItem(product, quantity);
    }
  };
  
  if (loading) {
    return (
      <>
        <Header />
        <main className="pt-24 pb-16">
          <div className="container-custom">
            <div className="animate-pulse">
              <div className="h-6 w-1/3 bg-muted rounded mb-3"></div>
              <div className="h-8 w-2/3 bg-muted rounded mb-8"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="aspect-square bg-muted rounded-lg"></div>
                <div className="space-y-4">
                  <div className="h-8 w-3/4 bg-muted rounded"></div>
                  <div className="h-6 w-1/4 bg-muted rounded"></div>
                  <div className="h-4 w-full bg-muted rounded mt-4"></div>
                  <div className="h-4 w-full bg-muted rounded"></div>
                  <div className="h-4 w-2/3 bg-muted rounded"></div>
                  <div className="h-12 w-full bg-muted rounded mt-8"></div>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }
  
  if (!product) {
    return (
      <>
        <Header />
        <main className="pt-24 pb-16">
          <div className="container-custom text-center py-16">
            <h1 className="text-2xl font-medium">Product Not Found</h1>
            <p className="mt-4 text-muted-foreground">
              Sorry, we couldn't find the product you were looking for.
            </p>
            <Link to="/products">
              <Button className="mt-6">Browse All Products</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }
  
  return (
    <>
      <Header />
      <main className="pt-24 pb-16">
        <div className="container-custom">
          {/* Breadcrumb */}
          <nav className="flex items-center text-sm mb-6">
            <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
              Home
            </Link>
            <ChevronRight size={14} className="mx-1 text-muted-foreground" />
            <Link to="/products" className="text-muted-foreground hover:text-foreground transition-colors">
              Products
            </Link>
            <ChevronRight size={14} className="mx-1 text-muted-foreground" />
            <Link 
              to={`/category/${product.category}`} 
              className="text-muted-foreground hover:text-foreground transition-colors capitalize"
            >
              {product.category}
            </Link>
            <ChevronRight size={14} className="mx-1 text-muted-foreground" />
            <span className="truncate">{product.name}</span>
          </nav>
          
          {/* Product Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="aspect-square overflow-hidden rounded-lg bg-muted/30">
                <img 
                  src={product.images?.[activeImageIndex] || product.image} 
                  alt={product.name}
                  className="h-full w-full object-cover"
                />
              </div>
              
              {product.images && product.images.length > 1 && (
                <div className="flex gap-3 overflow-auto pb-2">
                  {product.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveImageIndex(index)}
                      className={`relative aspect-square w-20 flex-shrink-0 overflow-hidden rounded-md ${
                        activeImageIndex === index ? "ring-2 ring-primary" : "ring-1 ring-border"
                      }`}
                    >
                      <img 
                        src={image} 
                        alt={`${product.name} - View ${index + 1}`}
                        className="h-full w-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            {/* Product Info */}
            <div>
              <div className="mb-2 flex items-center">
                <Link 
                  to={`/brand/${product.brand.toLowerCase()}`}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  {product.brand}
                </Link>
                <span className="mx-2 text-muted-foreground">•</span>
                <div className="flex items-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={14}
                      className={i < Math.floor(product.rating) ? "fill-amber-500 text-amber-500" : "text-muted"}
                    />
                  ))}
                  <span className="ml-1 text-sm font-medium">{product.rating}</span>
                  <span className="ml-1 text-sm text-muted-foreground">
                    ({reviews.length} {reviews.length === 1 ? "review" : "reviews"})
                  </span>
                </div>
              </div>
              
              <h1 className="text-3xl font-medium">{product.name}</h1>
              
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-2xl font-medium">
                  ${product.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                
                {product.bestSeller && (
                  <Badge className="bg-amber-500 hover:bg-amber-600 text-white">
                    Best Seller
                  </Badge>
                )}
                {product.new && (
                  <Badge className="bg-blue-500 hover:bg-blue-600 text-white">
                    New
                  </Badge>
                )}
              </div>
              
              <p className="mt-6 text-muted-foreground">
                {product.description}
              </p>
              
              <Separator className="my-6" />
              
              <div className="flex items-center gap-6">
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={decrementQuantity}
                    disabled={quantity <= 1}
                  >
                    <Minus size={14} />
                    <span className="sr-only">Decrease quantity</span>
                  </Button>
                  <span className="w-10 text-center">{quantity}</span>
                  <Button variant="outline" size="icon" onClick={incrementQuantity}>
                    <Plus size={14} />
                    <span className="sr-only">Increase quantity</span>
                  </Button>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  {product.inStock 
                    ? <span className="text-green-600 font-medium">In Stock</span>
                    : <span className="text-red-500 font-medium">Out of Stock</span>
                  }
                </div>
              </div>
              
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <Button 
                  className="sm:flex-1 flex items-center gap-2" 
                  size="lg"
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                >
                  <ShoppingBag size={16} />
                  Add to Cart
                </Button>
                <Button variant="outline" size="lg" className="sm:w-auto">
                  <Heart size={16} />
                  <span className="sr-only md:not-sr-only md:ml-2">Save</span>
                </Button>
              </div>
              
              <Separator className="my-6" />
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Truck size={18} className="mt-0.5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Free Shipping</h4>
                    <p className="text-sm text-muted-foreground">On orders over $50</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <RefreshCw size={18} className="mt-0.5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Easy Returns</h4>
                    <p className="text-sm text-muted-foreground">30-day return policy</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Shield size={18} className="mt-0.5 text-muted-foreground" />
                  <div>
                    <h4 className="font-medium">Secure Checkout</h4>
                    <p className="text-sm text-muted-foreground">Encrypted payment processing</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Product Tabs */}
          <Tabs defaultValue="details" className="mb-16">
            <TabsList className="mb-8">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="specs">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({reviews.length})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="details">
              <div className="prose max-w-none">
                <p className="text-muted-foreground">
                  {product.description}
                </p>
                <p className="text-muted-foreground mt-4">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, velit vel bibendum bibendum, odio velit bibendum nisi, vel bibendum velit velit vel bibendum bibendum, odio velit bibendum nisi, vel bibendum velit.
                </p>
                <p className="text-muted-foreground mt-4">
                  Sed euismod, velit vel bibendum bibendum, odio velit bibendum nisi, vel bibendum velit velit vel bibendum bibendum, odio velit bibendum nisi, vel bibendum velit.
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="specs">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <tbody>
                    <tr className="border-b">
                      <td className="py-3 pr-4 font-medium">Brand</td>
                      <td className="py-3">{product.brand}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 pr-4 font-medium">Category</td>
                      <td className="py-3 capitalize">{product.category}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 pr-4 font-medium">Material</td>
                      <td className="py-3">Premium Quality</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 pr-4 font-medium">Dimensions</td>
                      <td className="py-3">Varies by model</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 pr-4 font-medium">Weight</td>
                      <td className="py-3">Varies by model</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-3 pr-4 font-medium">Warranty</td>
                      <td className="py-3">1 Year Limited Warranty</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews">
              <div className="space-y-8">
                {reviews.length > 0 ? (
                  reviews.map((review) => (
                    <div key={review.id} className="border-b pb-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{review.author}</h4>
                          <div className="mt-1 flex items-center">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                size={14}
                                className={i < review.rating ? "fill-amber-500 text-amber-500" : "text-muted"}
                              />
                            ))}
                            <span className="ml-2 text-sm text-muted-foreground">
                              {new Date(review.date).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                      <p className="mt-3 text-muted-foreground">
                        {review.comment}
                      </p>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <h3 className="text-lg font-medium">No reviews yet</h3>
                    <p className="mt-2 text-muted-foreground">
                      Be the first to review this product
                    </p>
                    <Button className="mt-4">Write a Review</Button>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
          
          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div>
              <h2 className="text-2xl font-medium mb-6">Related Products</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {relatedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
};

export default ProductDetailPage;
