
import { useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Star } from "lucide-react";
import { Product } from "@/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useCart } from "@/hooks/use-cart";

interface ProductCardProps {
  product: Product;
  className?: string;
}

export const ProductCard = ({ product, className }: ProductCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const { addItem } = useCart();
  
  const { id, name, price, image, brand, rating, bestSeller, new: isNew, featured } = product;
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product, 1);
  };
  
  return (
    <Link
      to={`/product/${id}`}
      className={cn(
        "group block relative overflow-hidden rounded-lg bg-background transition-all duration-300",
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-square overflow-hidden rounded-lg">
        <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
          {bestSeller && (
            <Badge className="bg-amber-500 hover:bg-amber-600 text-white">
              Best Seller
            </Badge>
          )}
          {isNew && (
            <Badge className="bg-blue-500 hover:bg-blue-600 text-white">
              New
            </Badge>
          )}
          {featured && (
            <Badge className="bg-purple-500 hover:bg-purple-600 text-white">
              Featured
            </Badge>
          )}
        </div>
        
        <img
          src={image}
          alt={name}
          className={cn(
            "h-full w-full object-cover transition-transform duration-500",
            isHovered ? "scale-105" : "scale-100"
          )}
        />
        
        <div className="absolute inset-0 bg-black/5 transition-opacity duration-300"></div>
        
        <Button
          size="icon"
          onClick={handleAddToCart}
          className={cn(
            "absolute bottom-3 right-3 z-10 rounded-full shadow-md transition-all duration-300",
            isHovered ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
          )}
        >
          <Plus size={16} />
          <span className="sr-only">Add to cart</span>
        </Button>
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{brand}</p>
          <div className="flex items-center">
            <Star size={14} className="fill-amber-500 text-amber-500" />
            <span className="ml-1 text-sm font-medium">{rating}</span>
          </div>
        </div>
        
        <h3 className="mt-1 font-medium line-clamp-1">{name}</h3>
        <p className="mt-1 font-medium">
          ${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </p>
      </div>
    </Link>
  );
};
