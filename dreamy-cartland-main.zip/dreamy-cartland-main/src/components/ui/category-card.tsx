
import { Link } from "react-router-dom";
import { Category } from "@/types";
import { cn } from "@/lib/utils";

interface CategoryCardProps {
  category: Category;
  className?: string;
}

export const CategoryCard = ({ category, className }: CategoryCardProps) => {
  const { id, name, image, description } = category;
  
  return (
    <Link
      to={`/category/${id}`}
      className={cn(
        "group relative flex h-80 overflow-hidden rounded-lg",
        className
      )}
    >
      <img
        src={image}
        alt={name}
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
      />
      
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/70"></div>
      
      <div className="relative mt-auto p-6 text-white">
        <h3 className="text-xl font-medium">{name}</h3>
        <p className="mt-1 text-sm text-white/80">{description}</p>
        <span className="mt-3 inline-block border-b border-white/40 pb-0.5 text-sm font-medium transition-all duration-300 group-hover:border-white">
          Shop Now
        </span>
      </div>
    </Link>
  );
};
