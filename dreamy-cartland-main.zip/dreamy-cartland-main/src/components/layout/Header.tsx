
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ShoppingBag, Menu, X, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";

export const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cart } = useCart();
  const { user, logout } = useAuth();
  
  const cartItemsCount = cart.items.length;
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
    if (!isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  };
  
  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
    document.body.style.overflow = "";
  };
  
  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 w-full transition-all duration-300 ${
        isScrolled ? "bg-background/80 backdrop-blur-md shadow-subtle" : "bg-transparent"
      }`}
    >
      <div className="container-custom py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-xl font-medium" onClick={closeMobileMenu}>
            Luminous
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/products" className="text-sm font-medium link-hover">
              All Products
            </Link>
            <Link to="/category/electronics" className="text-sm font-medium link-hover">
              Electronics
            </Link>
            <Link to="/category/fashion" className="text-sm font-medium link-hover">
              Fashion
            </Link>
            <Link to="/category/home" className="text-sm font-medium link-hover">
              Home
            </Link>
          </nav>
          
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="hidden md:flex items-center space-x-4">
                <Link to="/account" className="text-sm font-medium link-hover flex items-center">
                  <User size={18} className="mr-1" />
                  Account
                </Link>
                <Button variant="ghost" size="sm" onClick={logout} className="text-sm font-medium">
                  Logout
                </Button>
              </div>
            ) : (
              <div className="hidden md:flex items-center space-x-4">
                <Link to="/login" className="text-sm font-medium link-hover">
                  Login
                </Link>
                <Link to="/signup">
                  <Button size="sm" variant="outline" className="text-sm">
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
            
            <Link to="/cart" className="relative flex items-center justify-center" aria-label="Cart">
              <ShoppingBag size={20} />
              {cartItemsCount > 0 && (
                <div className="absolute -top-1 -right-1 bg-primary text-primary-foreground rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-medium">
                  {cartItemsCount}
                </div>
              )}
            </Link>
            
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={toggleMobileMenu}
              aria-label="Menu"
            >
              <Menu size={20} />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-background z-50 animate-fade-in">
          <div className="container-custom py-4">
            <div className="flex justify-between items-center mb-8">
              <Link to="/" className="text-xl font-medium" onClick={closeMobileMenu}>
                Luminous
              </Link>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMobileMenu}
                aria-label="Close menu"
              >
                <X size={20} />
              </Button>
            </div>
            
            <nav className="flex flex-col space-y-6 text-lg">
              <Link to="/products" className="font-medium" onClick={closeMobileMenu}>
                All Products
              </Link>
              <Link to="/category/electronics" className="font-medium" onClick={closeMobileMenu}>
                Electronics
              </Link>
              <Link to="/category/fashion" className="font-medium" onClick={closeMobileMenu}>
                Fashion
              </Link>
              <Link to="/category/home" className="font-medium" onClick={closeMobileMenu}>
                Home
              </Link>
              
              {user ? (
                <>
                  <Link to="/account" className="font-medium" onClick={closeMobileMenu}>
                    Account
                  </Link>
                  <Button variant="ghost" onClick={() => { logout(); closeMobileMenu(); }} className="justify-start pl-0 font-medium">
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Link to="/login" className="font-medium" onClick={closeMobileMenu}>
                    Login
                  </Link>
                  <Link to="/signup" className="font-medium" onClick={closeMobileMenu}>
                    Sign Up
                  </Link>
                </>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};
