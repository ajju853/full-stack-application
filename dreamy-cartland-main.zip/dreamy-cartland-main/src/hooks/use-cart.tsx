
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { toast } from "sonner";
import { Product } from "@/types";

interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  cart: {
    items: CartItem[];
    subtotal: number;
  };
  addItem: (product: Product, quantity?: number) => void;
  updateItemQuantity: (productId: string, quantity: number) => void;
  removeItem: (productId: string) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [cart, setCart] = useState<{ items: CartItem[]; subtotal: number }>({
    items: [],
    subtotal: 0,
  });

  useEffect(() => {
    const storedCart = localStorage.getItem("cart");
    if (storedCart) {
      setCart(JSON.parse(storedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const calculateSubtotal = (items: CartItem[]) => {
    return items.reduce(
      (total, item) => total + item.product.price * item.quantity,
      0
    );
  };

  const addItem = (product: Product, quantity = 1) => {
    setCart((prevCart) => {
      const existingItemIndex = prevCart.items.findIndex(
        (item) => item.product.id === product.id
      );

      let updatedItems;

      if (existingItemIndex !== -1) {
        updatedItems = [...prevCart.items];
        updatedItems[existingItemIndex] = {
          ...updatedItems[existingItemIndex],
          quantity: updatedItems[existingItemIndex].quantity + quantity,
        };
      } else {
        updatedItems = [...prevCart.items, { product, quantity }];
      }

      const subtotal = calculateSubtotal(updatedItems);
      
      toast.success(`${product.name} added to cart`);
      
      return {
        items: updatedItems,
        subtotal,
      };
    });
  };

  const updateItemQuantity = (productId: string, quantity: number) => {
    if (quantity < 1) return;

    setCart((prevCart) => {
      const updatedItems = prevCart.items.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      );

      const subtotal = calculateSubtotal(updatedItems);

      return {
        items: updatedItems,
        subtotal,
      };
    });
  };

  const removeItem = (productId: string) => {
    setCart((prevCart) => {
      const updatedItems = prevCart.items.filter(
        (item) => item.product.id !== productId
      );

      const subtotal = calculateSubtotal(updatedItems);
      
      toast.success("Item removed from cart");

      return {
        items: updatedItems,
        subtotal,
      };
    });
  };

  const clearCart = () => {
    setCart({ items: [], subtotal: 0 });
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addItem,
        updateItemQuantity,
        removeItem,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};
