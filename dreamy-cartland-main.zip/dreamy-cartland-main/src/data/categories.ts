
import { Category } from "@/types";

export const categories: Category[] = [
  {
    id: "electronics",
    name: "Electronics",
    image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?q=80&w=800&h=800&auto=format&fit=crop",
    description: "Cutting-edge devices and gadgets for modern living",
  },
  {
    id: "fashion",
    name: "Fashion",
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&h=800&auto=format&fit=crop",
    description: "Timeless apparel and accessories for every occasion",
  },
  {
    id: "home",
    name: "Home",
    image: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?q=80&w=800&h=800&auto=format&fit=crop",
    description: "Beautiful and functional pieces for your living space",
  }
];

export const getCategoryById = (id: string) => {
  return categories.find(category => category.id === id);
};
