
import { Product } from "@/types";

export const products: Product[] = [
  {
    id: "1",
    name: "Wireless Noise-Cancelling Headphones",
    description: "Premium noise-cancelling headphones with superior sound quality and comfort for long listening sessions. Features 30-hour battery life, touch controls, and voice assistant compatibility.",
    price: 349.99,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "SoundMaster",
    rating: 4.8,
    inStock: true,
    featured: true,
    bestSeller: true
  },
  {
    id: "2",
    name: "Ultra-Slim Smartphone",
    description: "Cutting-edge smartphone with a 6.7-inch OLED display, professional-grade camera system, and all-day battery life in an elegant design.",
    price: 999.99,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1570891836654-32fbfd040877?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1560807707-8cc77767d783?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "TechPro",
    rating: 4.7,
    inStock: true,
    featured: true
  },
  {
    id: "3",
    name: "Smart Watch Series 5",
    description: "Advanced smartwatch with health tracking features, including ECG, sleep analysis, and fitness metrics. Water-resistant with a stunning always-on display.",
    price: 429.99,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1434494451490-ade7954c5db1?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "TechPro",
    rating: 4.6,
    inStock: true,
    bestSeller: true
  },
  {
    id: "4",
    name: "Minimalist Desk Lamp",
    description: "Sleek desk lamp with wireless charging pad, adjustable brightness, and color temperature settings. Perfect for your home office or bedside table.",
    price: 89.99,
    category: "home",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1540932239986-30128078f3c5?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "HomeStyle",
    rating: 4.5,
    inStock: true
  },
  {
    id: "5",
    name: "Premium Leather Wallet",
    description: "Handcrafted leather wallet with RFID protection, multiple card slots, and a sleek profile. Made from sustainably sourced full-grain leather.",
    price: 79.99,
    category: "fashion",
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1627123424574-724758594e93?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1606503825008-909a67e63c3d?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1559694097-9180c97f5e4c?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "Artisan",
    rating: 4.9,
    inStock: true,
    bestSeller: true
  },
  {
    id: "6",
    name: "Ceramic Pour-Over Coffee Set",
    description: "Elegant ceramic pour-over coffee maker with matching mug, featuring a precision-designed dripper for optimal extraction and flavor.",
    price: 64.99,
    category: "home",
    image: "https://images.unsplash.com/photo-1527683040093-3a2b80ed1592?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1527683040093-3a2b80ed1592?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1519095614420-850b5671ac7f?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "HomeStyle",
    rating: 4.7,
    inStock: true,
    featured: true
  },
  {
    id: "7",
    name: "Ultralight Travel Backpack",
    description: "Versatile backpack with dedicated laptop compartment, hidden security pockets, and expandable storage. Weatherproof material with comfortable straps.",
    price: 129.99,
    category: "fashion",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1581605405669-fcdf81165afa?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1542739674-b449a8938b59?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "TravelPro",
    rating: 4.8,
    inStock: true
  },
  {
    id: "8",
    name: "Portable Bluetooth Speaker",
    description: "Compact, waterproof Bluetooth speaker with 360° sound, 20-hour battery life, and built-in microphone for calls. Perfect for travel or outdoor activities.",
    price: 149.99,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1563330232-57114bb0823c?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1589003511513-eefa7a6155ad?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "SoundMaster",
    rating: 4.5,
    inStock: true
  },
  {
    id: "9",
    name: "Minimalist Analog Watch",
    description: "Elegant timepiece with sapphire crystal face, premium leather strap, and precise Japanese movement. Water-resistant with date display.",
    price: 199.99,
    category: "fashion",
    image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1509048191080-d2677e3bae48?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1539874754764-5a96559165b0?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "Chronos",
    rating: 4.7,
    inStock: true,
    featured: true
  },
  {
    id: "10",
    name: "Smart Home Security Camera",
    description: "High-definition security camera with motion detection, night vision, and two-way audio. Cloud storage and mobile app for remote monitoring.",
    price: 119.99,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1589935447067-5a0c3c61ee13?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1589935447067-5a0c3c61ee13?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1558002038-1055907df827?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556020685-ae41abfc9365?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "SecureTech",
    rating: 4.6,
    inStock: true
  },
  {
    id: "11",
    name: "Stainless Steel Water Bottle",
    description: "Vacuum-insulated water bottle that keeps drinks cold for 24 hours or hot for 12 hours. Leak-proof design with eco-friendly materials.",
    price: 34.99,
    category: "home",
    image: "https://images.unsplash.com/photo-1589365278144-c9e705f843ba?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1589365278144-c9e705f843ba?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556781366-336b0b7df577?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "EcoLife",
    rating: 4.9,
    inStock: true,
    bestSeller: true
  },
  {
    id: "12",
    name: "Merino Wool Sweater",
    description: "Luxurious merino wool sweater in a classic cut. Naturally temperature-regulating, odor-resistant, and incredibly soft against the skin.",
    price: 149.99,
    category: "fashion",
    image: "https://images.unsplash.com/photo-1585150595144-43ab336fb66b?q=80&w=1200&h=1200&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1585150595144-43ab336fb66b?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1516726817505-f5ed825624d8?q=80&w=1200&h=1200&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1559629279-041af9345bd3?q=80&w=1200&h=1200&auto=format&fit=crop"
    ],
    brand: "NatureFiber",
    rating: 4.8,
    inStock: true
  }
];

export const getProductById = (id: string) => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getFeaturedProducts = () => {
  return products.filter(product => product.featured);
};

export const getBestSellerProducts = () => {
  return products.filter(product => product.bestSeller);
};

export const getNewProducts = () => {
  return products.filter(product => product.new);
};

export const getRelatedProducts = (productId: string, limit = 4) => {
  const currentProduct = getProductById(productId);
  if (!currentProduct) return [];
  
  return products
    .filter(product => 
      product.id !== productId && 
      product.category === currentProduct.category
    )
    .slice(0, limit);
};
