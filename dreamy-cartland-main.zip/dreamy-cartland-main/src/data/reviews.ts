
import { Review } from "@/types";

export const reviews: Review[] = [
  {
    id: "1",
    productId: "1",
    rating: 5,
    author: "Sarah Johnson",
    comment: "These headphones are incredible! The noise cancellation is top-notch, and the sound quality is amazing. I wear them for hours without any discomfort.",
    date: "2023-09-15"
  },
  {
    id: "2",
    productId: "1",
    rating: 4,
    author: "Michael Lee",
    comment: "Very impressed with the sound quality and comfort. Battery life is excellent. The only minor issue is the app can be a bit glitchy at times.",
    date: "2023-08-21"
  },
  {
    id: "3",
    productId: "1",
    rating: 5,
    author: "Emma Wilson",
    comment: "Perfect for traveling and working from home. The noise cancellation helps me focus in noisy environments. Worth every penny!",
    date: "2023-10-03"
  },
  {
    id: "4",
    productId: "2",
    rating: 5,
    author: "David Chen",
    comment: "This is the best smartphone I've ever owned. The camera quality is spectacular, and the battery lasts all day even with heavy use.",
    date: "2023-07-12"
  },
  {
    id: "5",
    productId: "2",
    rating: 4,
    author: "Jessica Taylor",
    comment: "Excellent phone with stunning display and fast performance. Camera is amazing in low light. Only giving 4 stars because it's quite expensive.",
    date: "2023-08-07"
  },
  {
    id: "6",
    productId: "3",
    rating: 5,
    author: "Alex Rodriguez",
    comment: "This smartwatch has completely changed my fitness routine. The health tracking features are accurate, and I love getting notifications on my wrist.",
    date: "2023-09-18"
  },
  {
    id: "7",
    productId: "3",
    rating: 4,
    author: "Sophia Martinez",
    comment: "Great watch with excellent features. Battery life is better than expected. The only downside is occasionally slow app connectivity.",
    date: "2023-10-05"
  },
  {
    id: "8",
    productId: "4",
    rating: 5,
    author: "Ryan Kim",
    comment: "This lamp is both functional and beautiful. The wireless charging is convenient, and the adjustable lighting is perfect for my home office.",
    date: "2023-08-14"
  },
  {
    id: "9",
    productId: "5",
    rating: 5,
    author: "Olivia Johnson",
    comment: "Excellent quality leather and craftsmanship. The wallet is slim yet holds everything I need. RFID protection gives me peace of mind.",
    date: "2023-09-27"
  },
  {
    id: "10",
    productId: "6",
    rating: 5,
    author: "Daniel Brown",
    comment: "Coffee tastes noticeably better with this pour-over set. The ceramic retains heat well, and the design is simply beautiful on my countertop.",
    date: "2023-07-30"
  }
];

export const getReviewsByProductId = (productId: string) => {
  return reviews.filter(review => review.productId === productId);
};

export const getAverageRatingByProductId = (productId: string) => {
  const productReviews = getReviewsByProductId(productId);
  if (productReviews.length === 0) return 0;
  
  const sum = productReviews.reduce((total, review) => total + review.rating, 0);
  return sum / productReviews.length;
};
